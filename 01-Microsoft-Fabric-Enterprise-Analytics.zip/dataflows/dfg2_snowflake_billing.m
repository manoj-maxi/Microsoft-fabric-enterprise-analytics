// Dataflow Gen2 — Snowflake Billing (incremental)
// Power Query (M). Reusable entity feeding the Bronze Lakehouse.
// Pattern: parameterized incremental pull + schema enforcement + error handling.

let
    // --- Parameters (bound at refresh) ---
    pWatermark = DateTime.From( #"Last Watermark" ),   // pulled from a parameter query

    // --- Source: Snowflake ---
    Source = Snowflake.Databases(
        "myaccount.snowflakecomputing.com",
        "WH_ETL_XS",
        [Role = "ROLE_ETL_READER"]
    ),
    BillingDb   = Source{[Name = "BILLING"]}[Data],
    PublicSchema = BillingDb{[Name = "PUBLIC"]}[Data],
    InvoiceLine = PublicSchema{[Name = "INVOICE_LINE"]}[Data],

    // --- Incremental filter (query folds to Snowflake) ---
    Incremental = Table.SelectRows(
        InvoiceLine,
        each [MODIFIED_TS] > pWatermark
    ),

    // --- Type enforcement (schema contract) ---
    Typed = Table.TransformColumnTypes(
        Incremental,
        {
            {"INVOICE_ID",      type text},
            {"INVOICE_LINE_ID", type text},
            {"CUSTOMER_ID",     type text},
            {"PRODUCT_CODE",    type text},
            {"BUSINESS_UNIT",   type text},
            {"INVOICE_DATE",    type date},
            {"AMOUNT",          type number},
            {"CURRENCY",        type text},
            {"MODIFIED_TS",     type datetime}
        }
    ),

    // --- Error handling: replace conversion errors, flag bad rows ---
    Cleaned = Table.ReplaceErrorValues(
        Typed,
        {{"AMOUNT", 0.0}, {"INVOICE_DATE", null}}
    ),
    Flagged = Table.AddColumn(
        Cleaned,
        "dq_flag",
        each if [INVOICE_ID] = null or [AMOUNT] < 0 then "QUARANTINE" else "PASS",
        type text
    ),

    // --- Audit columns ---
    WithAudit = Table.AddColumn(
        Table.AddColumn(Flagged, "_source_system", each "Snowflake", type text),
        "_load_ts", each DateTimeZone.UtcNow(), type datetimezone
    )
in
    WithAudit
