// Dataflow Gen2 — Vendor Settlement REST API (cursor pagination)
// Power Query (M). Pulls paged JSON, flattens, enforces schema.

let
    BaseUrl   = "https://api.vendor-settlement.example.com/v2/settlements",
    PageSize  = 500,
    SinceTs   = DateTime.ToText( #"Last Watermark", "yyyy-MM-ddTHH:mm:ssZ" ),

    // Recursive page fetch until the API returns an empty page
    GetPage = (page as number) as list =>
        let
            Url  = BaseUrl & "?since=" & SinceTs
                          & "&page="  & Text.From(page)
                          & "&limit=" & Text.From(PageSize),
            Resp = Json.Document(
                Web.Contents(Url, [
                    Headers = [ #"Authorization" = "Bearer " & #"API Token",
                                #"Accept" = "application/json" ],
                    ManualStatusHandling = {429, 500, 502, 503}   // handle throttling/transient
                ])
            ),
            Rows = try Resp[data] otherwise {},
            Next = if List.Count(Rows) < PageSize then Rows
                   else Rows & @GetPage(page + 1)
        in
            Next,

    AllRows  = GetPage(1),
    AsTable  = Table.FromList(AllRows, Splitter.SplitByNothing(), {"rec"}),

    // Expand JSON record fields
    Expanded = Table.ExpandRecordColumn(
        AsTable, "rec",
        {"settlement_id", "vendor_id", "vendor_name", "period",
         "settlement_amount", "currency", "status", "modified_ts"}
    ),

    // Schema enforcement
    Typed = Table.TransformColumnTypes(
        Expanded,
        {
            {"settlement_id",     type text},
            {"vendor_id",         type text},
            {"vendor_name",       type text},
            {"period",            type text},
            {"settlement_amount", type number},
            {"currency",          type text},
            {"status",            type text},
            {"modified_ts",       type datetime}
        }
    ),

    // Keep only finalized settlements; audit columns
    Final = Table.AddColumn(
        Table.SelectRows(Typed, each [status] = "FINAL"),
        "_source_system", each "VendorAPI", type text
    )
in
    Final
