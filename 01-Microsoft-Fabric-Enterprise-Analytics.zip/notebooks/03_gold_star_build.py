# Fabric Notebook: 03_gold_star_build
# Builds the Gold Kimball star schema from Silver and V-Order optimizes for Direct Lake.

from pyspark.sql import functions as F

LH = "lh_enterprise_analytics"
spark.conf.set("spark.sql.parquet.vorder.enabled", "true")   # V-Order for Direct Lake

# ---------------------------------------------------------------------------
# dim_date  (generated calendar)
# ---------------------------------------------------------------------------
if not spark.catalog.tableExists(f"{LH}.dim_date"):
    dates = spark.sql("""
        SELECT explode(sequence(to_date('2018-01-01'), to_date('2030-12-31'), interval 1 day)) AS date
    """)
    dim_date = (dates
        .withColumn("date_key",     F.date_format("date", "yyyyMMdd").cast("int"))
        .withColumn("year",         F.year("date"))
        .withColumn("quarter",      F.concat(F.lit("Q"), F.quarter("date")))
        .withColumn("month_no",     F.month("date"))
        .withColumn("month_name",   F.date_format("date", "MMMM"))
        .withColumn("year_month",   F.date_format("date", "yyyy-MM"))
        .withColumn("day_of_week",  F.date_format("date", "EEEE"))
        .withColumn("is_weekend",   F.dayofweek("date").isin(1, 7))
        .withColumn("is_month_end", F.col("date") == F.last_day("date")))
    dim_date.write.format("delta").saveAsTable(f"{LH}.dim_date")

# ---------------------------------------------------------------------------
# fact_revenue  (joins invoice -> surrogate keys, declares grain)
# ---------------------------------------------------------------------------
inv = spark.table(f"{LH}.silver_invoice").filter("dq_status = 'PASS'")
dim_cust = (spark.table(f"{LH}.dim_customer")
            .filter("is_current = true")
            .select("customer_id", F.monotonically_increasing_id().alias("customer_sk")))

fact_revenue = (inv
    .join(dim_cust, "customer_id", "left")
    .withColumn("customer_sk", F.coalesce(F.col("customer_sk"), F.lit(-1)))   # -1 = Unknown member
    .withColumn("date_key", F.date_format("invoice_date", "yyyyMMdd").cast("int"))
    .select(
        "invoice_id", "invoice_line_id",
        "customer_sk", "date_key",
        "product_code", "business_unit",
        "invoice_amount", "currency"))

(fact_revenue.write.format("delta").mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(f"{LH}.fact_revenue"))

# ---------------------------------------------------------------------------
# Maintenance: OPTIMIZE (V-Order) + VACUUM for Direct Lake read performance
# ---------------------------------------------------------------------------
for t in ["fact_revenue", "fact_usage", "fact_cost", "dim_customer", "dim_date"]:
    if spark.catalog.tableExists(f"{LH}.{t}"):
        spark.sql(f"OPTIMIZE {LH}.{t}")          # compacts + V-Order
        spark.sql(f"VACUUM {LH}.{t} RETAIN 168 HOURS")

print("[GOLD] star schema built and optimized for Direct Lake")
mssparkutils.notebook.exit("GOLD_OK")
