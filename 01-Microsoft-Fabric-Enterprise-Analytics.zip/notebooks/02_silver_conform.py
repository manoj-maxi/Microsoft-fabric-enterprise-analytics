# Fabric Notebook: 02_silver_conform
# Reads Bronze, applies data quality + conforming, and MERGEs into Silver.
# Dimensions use SCD Type 2; facts are cleansed and deduplicated.

from pyspark.sql import functions as F, Window
from delta.tables import DeltaTable

LH = "lh_enterprise_analytics"

# ===========================================================================
# 1. FACT: silver_invoice  (cleanse + dedup, no SCD)
# ===========================================================================
bronze = spark.table(f"{LH}.bronze_billing_invoices")

# Data-quality rules -> dq_status
dq = (bronze
    .withColumn("dq_status",
        F.when(F.col("INVOICE_ID").isNull(), F.lit("QUARANTINE"))
         .when(F.col("AMOUNT") < 0,          F.lit("QUARANTINE"))
         .when(F.col("CUSTOMER_ID").isNull(),F.lit("WARN"))
         .otherwise(F.lit("PASS")))
)

# Quarantine bad rows for steward review
(dq.filter("dq_status = 'QUARANTINE'")
   .write.format("delta").mode("append")
   .saveAsTable(f"{LH}.silver_invoice_quarantine"))

# Dedup: keep latest extract per natural key
w = Window.partitionBy("INVOICE_ID", "INVOICE_LINE_ID").orderBy(F.col("_load_ts").desc())
clean = (dq.filter("dq_status <> 'QUARANTINE'")
    .withColumn("_rn", F.row_number().over(w))
    .filter("_rn = 1").drop("_rn"))

silver_invoice = (clean.select(
    F.col("INVOICE_ID").alias("invoice_id"),
    F.col("INVOICE_LINE_ID").alias("invoice_line_id"),
    F.col("CUSTOMER_ID").alias("customer_id"),
    F.col("PRODUCT_CODE").alias("product_code"),
    F.col("BUSINESS_UNIT").alias("business_unit"),
    F.to_date("INVOICE_DATE").alias("invoice_date"),
    F.col("AMOUNT").cast("decimal(18,2)").alias("invoice_amount"),
    F.col("CURRENCY").alias("currency"),
    F.col("dq_status"),
    F.col("_load_ts"),
))

# Idempotent MERGE into Silver
if spark.catalog.tableExists(f"{LH}.silver_invoice"):
    tgt = DeltaTable.forName(spark, f"{LH}.silver_invoice")
    (tgt.alias("t").merge(
        silver_invoice.alias("s"),
        "t.invoice_id = s.invoice_id AND t.invoice_line_id = s.invoice_line_id")
        .whenMatchedUpdateAll()
        .whenNotMatchedInsertAll()
        .execute())
else:
    silver_invoice.write.format("delta").saveAsTable(f"{LH}.silver_invoice")

# ===========================================================================
# 2. DIMENSION: silver_customer_scd2  (SCD Type 2)
# ===========================================================================
src = (spark.table(f"{LH}.bronze_customer")
    .select(
        F.col("CUSTOMER_ID").alias("customer_id"),
        F.col("CUSTOMER_NAME").alias("customer_name"),
        F.col("SEGMENT").alias("segment"),
        F.col("REGION").alias("region"),
        F.col("BUSINESS_UNIT").alias("business_unit"),
    ))

# Hash of tracked attributes to detect change
track_cols = ["customer_name", "segment", "region", "business_unit"]
src = src.withColumn("row_hash", F.sha2(F.concat_ws("||", *track_cols), 256))
src = src.withColumn("valid_from", F.current_timestamp()) \
         .withColumn("valid_to",   F.lit(None).cast("timestamp")) \
         .withColumn("is_current", F.lit(True))

dim_name = f"{LH}.dim_customer"

if not spark.catalog.tableExists(dim_name):
    src.write.format("delta").saveAsTable(dim_name)
else:
    dim = DeltaTable.forName(spark, dim_name)
    current = spark.table(dim_name).filter("is_current = true").select("customer_id", "row_hash")

    # Rows whose hash changed = need a new version; expire the old.
    changed = (src.alias("s").join(current.alias("c"), "customer_id", "left")
        .filter("c.row_hash IS NULL OR s.row_hash <> c.row_hash")
        .select("s.*"))

    # Step 1: expire changed current rows
    (dim.alias("t").merge(
        changed.alias("s"), "t.customer_id = s.customer_id AND t.is_current = true")
        .whenMatchedUpdate(set={
            "is_current": F.lit(False),
            "valid_to":   F.current_timestamp()})
        .execute())

    # Step 2: insert the new versions
    changed.write.format("delta").mode("append").saveAsTable(dim_name)

print("[SILVER] conform complete: silver_invoice + dim_customer SCD2")
mssparkutils.notebook.exit("SILVER_OK")
