# Fabric Notebook: 01_bronze_ingest
# Lands raw source data into the Bronze zone of the Lakehouse as Delta tables.
# Append-only with audit columns. No business logic in Bronze.
#
# Attached Lakehouse: lh_enterprise_analytics
# Parameters (set by the orchestrating pipeline via %%configure / pipeline params):
#   source_system, source_object, target_bronze_table, load_type, watermark_column, watermark_value, batch_id

from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from datetime import datetime, timezone

# ---- Parameters (defaults overridden by pipeline) -------------------------
source_system       = "Snowflake"
source_object       = "BILLING.PUBLIC.INVOICE_LINE"
target_bronze_table = "bronze_billing_invoices"
load_type           = "INCREMENTAL"
watermark_column    = "MODIFIED_TS"
watermark_value     = "2024-01-01 00:00:00"
batch_id            = "manual-run"

load_ts = datetime.now(timezone.utc)

# ---- Read from source -----------------------------------------------------
def read_source():
    """Reads from source using the appropriate connector. Incremental where supported."""
    if source_system == "Snowflake":
        opts = {
            "sfUrl":       dbutils.secrets.get("kv-fabric", "sf-url"),
            "sfUser":      dbutils.secrets.get("kv-fabric", "sf-user"),
            "sfDatabase":  "BILLING",
            "sfSchema":    "PUBLIC",
            "sfWarehouse": "WH_ETL_XS",
            "sfRole":      "ROLE_ETL_READER",
        }
        query = f"SELECT * FROM {source_object}"
        if load_type == "INCREMENTAL":
            query += f" WHERE {watermark_column} > '{watermark_value}'"
        return (spark.read.format("net.snowflake.spark.snowflake")
                .options(**opts).option("query", query).load())

    elif source_system == "SQLServer":
        jdbc = dbutils.secrets.get("kv-fabric", "sqlserver-jdbc")
        pred = f"{watermark_column} > '{watermark_value}'" if load_type == "INCREMENTAL" else "1=1"
        return (spark.read.format("jdbc")
                .option("url", jdbc)
                .option("dbtable", f"(SELECT * FROM {source_object} WHERE {pred}) q")
                .load())

    elif source_system == "Oracle":
        jdbc = dbutils.secrets.get("kv-fabric", "oracle-jdbc")
        pred = f"{watermark_column} > TIMESTAMP '{watermark_value}'" if load_type == "INCREMENTAL" else "1=1"
        return (spark.read.format("jdbc")
                .option("url", jdbc)
                .option("dbtable", f"(SELECT * FROM {source_object} WHERE {pred})")
                .load())
    else:
        raise ValueError(f"Unsupported source_system: {source_system}")

df = read_source()

# ---- Add audit / lineage columns -----------------------------------------
df_bronze = (df
    .withColumn("_source_system", F.lit(source_system))
    .withColumn("_source_object", F.lit(source_object))
    .withColumn("_load_ts",       F.lit(load_ts).cast("timestamp"))
    .withColumn("_batch_id",      F.lit(batch_id))
    .withColumn("_ingest_date",   F.to_date(F.lit(load_ts).cast("timestamp")))
)

# ---- Write to Bronze (Delta, partitioned by ingest date) ------------------
row_count = df_bronze.count()
print(f"[BRONZE] {target_bronze_table}: writing {row_count:,} rows (batch {batch_id})")

(df_bronze.write
    .format("delta")
    .mode("append")
    .partitionBy("_ingest_date")
    .option("mergeSchema", "true")        # tolerate additive source schema drift
    .saveAsTable(f"lh_enterprise_analytics.{target_bronze_table}"))

# ---- Emit row count for pipeline validation -------------------------------
mssparkutils.notebook.exit(str(row_count))
