# Capacity (CU) Sizing

## Approach

Fabric capacity is measured in **Capacity Units (CU)**. The platform runs on an **F64** SKU after right-sizing from an over-provisioned legacy Premium **P1**.

## Workload profile

| Workload | When | Relative CU draw |
|----------|------|-----------------|
| Pipeline ingestion (Data Factory) | 02:00–04:00 nightly | High, batched off-peak |
| PySpark notebooks (transform) | 02:30–05:00 | High, off-peak |
| Direct Lake queries (dashboards) | 08:00–19:00 business hours | Medium, interactive |
| Dataflow Gen2 refresh | hourly on critical feeds | Low–medium |
| Paginated report rendering | scheduled + on-demand | Low |

By scheduling heavy ETL **off-peak** and serving dashboards via **Direct Lake** (no import refresh spikes), interactive and background workloads don't collide.

## Sizing method

1. **Baseline:** ran a 2-week pilot on F64 capturing CU seconds in the **Microsoft Fabric Capacity Metrics** app.
2. **Peak analysis:** identified the 95th-percentile interactive load (≈ 70% of F64) during month-end close — the busiest window.
3. **Smoothing:** Fabric's 24h smoothing absorbs background ETL bursts; verified no sustained throttling.
4. **Headroom:** kept ~25–30% headroom for month-end and ad-hoc spikes.

## Monitoring & throttling guardrails

- **Capacity Metrics app** tracked daily: CU utilization, overages, throttling, and Direct Lake **fallback-to-DirectQuery** frequency.
- Alert when sustained utilization > 85% for > 30 min → review before it throttles interactive users.
- Hot tables causing Direct Lake fallback get an **aggregation table** rather than an immediate SKU bump.

## Cost outcome

Right-sizing from the legacy P1 to a correctly scheduled F64, plus eliminating import-refresh CU spikes via Direct Lake, reduced capacity cost ~22% while improving dashboard responsiveness.
