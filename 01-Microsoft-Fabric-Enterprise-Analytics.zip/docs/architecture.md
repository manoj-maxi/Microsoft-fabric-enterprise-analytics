# Architecture

## End-to-end platform

```mermaid
flowchart TB
    subgraph SRC["Source Systems"]
        SF[(Snowflake<br/>Billing & Rated Usage)]
        SQL[(SQL Server<br/>Switch CDRs)]
        ORA[(Oracle EBS<br/>General Ledger)]
        REST[REST API<br/>Vendor Settlement]
        D365[Dynamics 365<br/>Customer & Contracts]
    end

    subgraph FAB["Microsoft Fabric Workspace (OneLake)"]
        direction TB

        subgraph ING["Ingestion"]
            PIPE[Fabric Data Factory<br/>Metadata-driven Pipelines]
            DFG2[Dataflow Gen2<br/>Power Query M]
        end

        subgraph LAKE["Lakehouse — Delta on OneLake"]
            BRONZE["🥉 Bronze<br/>Raw, append-only"]
            SILVER["🥈 Silver<br/>Conformed, SCD2, DQ"]
            GOLD["🥇 Gold<br/>Kimball Star Schema"]
        end

        NB[PySpark Notebooks<br/>Transform & DQ]
        WH[(Warehouse<br/>SQL endpoint)]
        SEM[[Direct Lake<br/>Certified Semantic Model]]
    end

    subgraph GOV["Governance Plane"]
        PURVIEW[Microsoft Purview<br/>Lineage • Catalog • Sensitivity • DLP]
        DEPLOY[Deployment Pipelines<br/>Dev → Test → Prod]
        RLS[RLS / OLS / RBAC]
    end

    subgraph BI["Consumption"]
        EXEC[Executive Dashboards]
        OPS[Operational Reports]
        PAGE[Paginated Regulatory PDFs]
    end

    SF --> PIPE
    SQL --> PIPE
    ORA --> PIPE
    REST --> DFG2
    D365 --> DFG2

    PIPE --> BRONZE
    DFG2 --> BRONZE
    BRONZE --> NB
    NB --> SILVER
    SILVER --> NB
    NB --> GOLD
    GOLD --> WH
    GOLD --> SEM

    SEM --> EXEC
    SEM --> OPS
    WH --> PAGE

    PURVIEW -.scans & labels.-> LAKE
    DEPLOY -.promotes.-> FAB
    RLS -.secures.-> SEM
```

## Component responsibilities

| Component | Responsibility | Why this choice |
|-----------|---------------|-----------------|
| **Fabric Data Factory** | Orchestrates high-volume, code-first ingestion from databases with CDC/watermark | Native to Fabric, ForEach metadata loop, integrates with OneLake without staging copies |
| **Dataflow Gen2** | Low-code ingestion of REST + SaaS sources, reusable M transforms | Citizen-developer friendly, reusable entities, writes straight to Lakehouse |
| **Lakehouse (Delta)** | Single storage for all three medallion zones | ACID Delta, time travel, schema enforcement, queryable by Spark + SQL + Direct Lake |
| **PySpark Notebooks** | Heavy transformation, SCD2, data quality, conforming | Scales to billion-row CDR volumes; expresses complex logic better than M |
| **Warehouse** | T-SQL surface for paginated reports and ad-hoc SQL | Familiar SQL endpoint; serves Report Builder which can't read Direct Lake directly |
| **Direct Lake semantic model** | Serves Power BI with VertiPaq-speed reads on Delta | No import refresh, no data duplication, sub-second on large fact tables |
| **Purview** | Lineage, business glossary, sensitivity labels, DLP | Enterprise audit/compliance requirement (SOX, GDPR) |
| **Deployment Pipelines** | Promote artifacts Dev → Test → Prod with rules | Repeatable, auditable releases; parameter rebinding per stage |

## Direct Lake vs DirectQuery vs Import — decision

Direct Lake was chosen for the executive model because it reads the Gold Delta tables directly from OneLake at VertiPaq speed **without** an import refresh cycle or data duplication. Guardrails:

- Gold tables are V-Order optimized and kept under the per-table guardrail row/size limits for the F-SKU.
- If a query exceeds Direct Lake limits it **falls back to DirectQuery** automatically — we monitor fallback frequency in the Capacity Metrics app and address hot tables with aggregations.
- Paginated reports (which require DirectQuery/SQL) read the Warehouse SQL endpoint instead.

## Data flow narrative

1. A scheduled Fabric pipeline reads a **control/metadata table** listing each source entity, its incremental key, and its watermark.
2. For each entity (`ForEach`): `Lookup` last watermark → `Copy Activity` pulls only changed rows → lands in **Bronze** as Delta with audit columns.
3. A **PySpark notebook** reads Bronze, applies type casting, dedup, and data-quality rules, and merges into **Silver** with SCD Type 2 on dimensions.
4. A second notebook builds the **Gold** Kimball star schema (fact + conformed dimensions), V-Order optimized.
5. The **Direct Lake semantic model** points at Gold; Power BI dashboards query it live.
6. **Purview** scans lineage end-to-end; **Deployment Pipelines** promote the workspace through environments.
