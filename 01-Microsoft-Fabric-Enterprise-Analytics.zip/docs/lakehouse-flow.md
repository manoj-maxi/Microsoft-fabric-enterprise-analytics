# Lakehouse Medallion Flow

The Lakehouse follows a three-zone medallion pattern on Delta tables stored in OneLake.

```mermaid
flowchart LR
    subgraph BRONZE["🥉 BRONZE — Raw"]
        b1[bronze_billing_invoices]
        b2[bronze_usage_cdr]
        b3[bronze_gl_journal]
        b4[bronze_vendor_settlement]
        b5[bronze_customer]
    end
    subgraph SILVER["🥈 SILVER — Conformed"]
        s1[silver_invoice]
        s2[silver_usage]
        s3[silver_gl]
        s4[silver_settlement]
        s5[silver_customer_scd2]
    end
    subgraph GOLD["🥇 GOLD — Star Schema"]
        f1[[fact_revenue]]
        f2[[fact_usage]]
        f3[[fact_cost]]
        d1[dim_customer]
        d2[dim_date]
        d3[dim_product]
        d4[dim_business_unit]
        d5[dim_vendor]
    end

    b1 --> s1 --> f1
    b2 --> s2 --> f2
    b3 --> s3 --> f1
    b4 --> s4 --> f3
    b5 --> s5 --> d1
    d2 -.conforms.- f1 & f2 & f3
    d3 -.conforms.- f1 & f2
    d4 -.conforms.- f1 & f3
    d5 -.conforms.- f3
```

## Zone contracts

### Bronze — Raw landing
- **Rule:** exact copy of source. No filtering, no business logic, no dedup.
- **Format:** Delta, append-only (idempotent re-runs use `_batch_id`).
- **Audit columns added:** `_source_system`, `_load_ts`, `_batch_id`, `_file_name`, `_is_current_extract`.
- **Retention:** 90 days rolling, then archived to a cold Lakehouse path.

### Silver — Conformed / cleansed
- Type casting and standardized data types.
- Deduplication on natural keys.
- Data-quality rules with `dq_status` flags (`PASS` / `WARN` / `QUARANTINE`).
- Standardized keys (trim, upper, surrogate-key lookups).
- **SCD Type 2** on dimensions (`valid_from`, `valid_to`, `is_current`, `row_hash`).
- Quarantined rows route to `silver_<entity>_quarantine` for steward review (visible in Purview).

### Gold — Presentation (Kimball star)
- Conformed dimensions shared across facts.
- Additive/semi-additive fact tables at declared grain.
- Surrogate keys, no source IDs in facts except degenerate dimensions.
- **V-Order** optimized + `OPTIMIZE` / `VACUUM` maintenance for Direct Lake performance.
- Only Gold is exposed to the semantic model.

## Data quality framework (Silver)

| Check | Example | Action on fail |
|-------|---------|----------------|
| Not-null on keys | `invoice_id IS NOT NULL` | QUARANTINE |
| Referential integrity | every `customer_id` exists in dim | WARN + default to `-1 Unknown` member |
| Range / domain | `amount >= 0`, `currency IN (...)` | QUARANTINE |
| Duplicate detection | distinct on natural key + period | keep latest by `_load_ts` |
| Freshness | source watermark within SLA | WARN, alert pipeline owner |

## Table grain declarations

| Gold table | Grain |
|------------|-------|
| `fact_revenue` | one row per invoice line per accounting period |
| `fact_usage` | one row per rated usage event aggregated to subscriber-day |
| `fact_cost` | one row per vendor settlement line per period |
| `dim_customer` | one row per customer per SCD2 version |
| `dim_date` | one row per calendar day |
