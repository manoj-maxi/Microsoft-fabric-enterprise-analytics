# Direct Lake Semantic Model

## Star schema

```mermaid
erDiagram
    fact_revenue }o--|| dim_customer : customer_sk
    fact_revenue }o--|| dim_date : date_key
    fact_revenue }o--|| dim_product : product_code
    fact_revenue }o--|| dim_business_unit : business_unit
    fact_cost }o--|| dim_vendor : vendor_sk
    fact_cost }o--|| dim_date : date_key
    fact_usage }o--|| dim_customer : customer_sk
    fact_usage }o--|| dim_date : date_key

    dim_customer {
        bigint customer_sk PK
        string customer_id
        string customer_name
        string segment
        string region
        string business_unit
        timestamp valid_from
        timestamp valid_to
        bool is_current
    }
    dim_date {
        int date_key PK
        date date
        int year
        string quarter
        string year_month
        bool is_month_end
    }
    fact_revenue {
        string invoice_id
        bigint customer_sk FK
        int date_key FK
        decimal invoice_amount
        string currency
    }
    fact_cost {
        bigint vendor_sk FK
        int date_key FK
        decimal settlement_amount
    }
    fact_usage {
        bigint customer_sk FK
        int date_key FK
        decimal rated_amount
    }
```

## Storage mode decisions

| Table | Storage mode | Reason |
|-------|-------------|--------|
| fact_revenue | **Direct Lake** | Large, queried live, V-Order optimized |
| fact_usage | **Direct Lake** | Billion-row scale; no import would fit refresh window |
| fact_cost | **Direct Lake** | Consistent with facts |
| dim_* | **Direct Lake** | Small, but kept in Direct Lake for single-mode consistency |
| MetricSelector | Import | Disconnected helper table for dynamic measure switching |

## Model design rules applied

- **Single direction filters** from dimensions to facts (avoid ambiguity).
- **Mark dim_date as a date table** to enable time intelligence.
- **Hide surrogate keys** (`customer_sk`, `date_key`) from report view; expose only attributes and measures.
- **Inactive role-playing relationships** for order/ship dates handled via `USERELATIONSHIP`.
- **`-1` Unknown member** in each dimension catches orphan fact rows so totals always reconcile.
- **Aggregation table** on `fact_usage` (pre-summed to customer-month) for high-level visuals; detail falls through to the base table only when needed.

## Direct Lake guardrails

- Gold tables kept within the F-SKU's Direct Lake per-table limits (rows + Parquet size).
- `OPTIMIZE` (V-Order) + `VACUUM` run at the end of every Gold load to keep file layout efficient.
- Fallback-to-DirectQuery is **monitored** in the Capacity Metrics app; frequent fallback on a table triggers either an aggregation table or a capacity bump.
- The model is endorsed as a **Certified dataset** so report authors reuse it instead of building shadow imports.
