# Governance & Security

## Layers of control

```mermaid
flowchart TB
    subgraph Identity
        AAD[Microsoft Entra ID<br/>Groups]
    end
    subgraph Fabric
        WS[Workspace Roles<br/>Admin/Member/Contributor/Viewer]
        RLS[Row-Level Security<br/>by Business Unit]
        OLS[Object-Level Security<br/>PII columns]
        CERT[Certified Dataset<br/>Endorsement]
    end
    subgraph Purview
        MAP[Data Map / Scan]
        CAT[Business Glossary]
        LIN[End-to-end Lineage]
        SENS[Sensitivity Labels + DLP]
    end
    AAD --> WS --> RLS --> OLS
    Purview -.scans.-> Fabric
    CERT --> Consumers((Report Authors))
```

## Row-Level Security (RLS)

A security table maps Entra ID security groups to business units. RLS DAX filter on `dim_business_unit`:

```dax
[Business Unit] =
LOOKUPVALUE (
    UserBUMap[business_unit],
    UserBUMap[user_email], USERPRINCIPALNAME ()
)
```

Finance leadership group sees all BUs (no filter); BU managers see only their unit.

## Object-Level Security (OLS)

PII columns (`customer_name`, contract identifiers) hidden via OLS from the `Operational-Viewer` role; the `Compliance` role retains visibility. Configured in Tabular Editor on the role definition.

## Microsoft Purview

| Capability | Use here |
|-----------|----------|
| Data Map | Automated scan of OneLake, Azure SQL, Synapse |
| Lineage | Source → Bronze → Silver → Gold → semantic model → report, visualized end to end |
| Business glossary | KPI definitions linked to physical columns |
| Sensitivity labels | `Confidential — Financial`, `PII` auto-applied; flow to exported files |
| DLP | Blocks export of PII-labeled data to unmanaged locations |

## Compliance mapping

| Regulation | Control implemented |
|-----------|--------------------|
| **SOX** | Certified datasets, change control via Deployment Pipelines, audit-ready run logs |
| **GDPR** | OLS/RLS on PII, sensitivity labels, DLP, data subject lineage in Purview |
| **Regulation W** | Affiliate-transaction segregation enforced via RLS on `dim_business_unit` |

## CI/CD — Deployment Pipelines

```mermaid
flowchart LR
    DEV[Dev Workspace] -->|deploy rules:<br/>rebind data sources| TEST[Test Workspace]
    TEST -->|approval gate| PROD[Prod Workspace]
    GIT[(Git integration<br/>workspace source control)] -.syncs.- DEV
```

- Workspace **Git integration** version-controls semantic model + reports.
- **Deployment rules** rebind connection strings and parameters per stage (Dev points to dev Lakehouse, Prod to prod).
- Promotion to Prod requires reviewer approval — auditable for SOX.
