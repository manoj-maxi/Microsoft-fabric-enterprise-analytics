# KPI Catalog

Business definitions for every executive KPI, with grain, owner, and the backing DAX measure.

| KPI | Definition | Grain | Owner | DAX measure |
|-----|-----------|-------|-------|-------------|
| Total Revenue | Sum of billed invoice line amounts | Invoice line / period | Finance | `[Total Revenue]` |
| Revenue YoY % | Revenue growth vs same period last year | Period | Finance | `[Revenue YoY %]` |
| Revenue MoM % | Revenue growth vs prior month | Month | Finance | `[Revenue MoM %]` |
| Revenue Leakage | Rated usage that exceeds billed revenue (under-billing) | Customer / month | Revenue Assurance | `[Revenue Leakage]` |
| Revenue Leakage % | Leakage as a share of rated usage | Customer / month | Revenue Assurance | `[Revenue Leakage %]` |
| Total Cost | Vendor settlement spend | Settlement line / period | Cost Assurance | `[Total Cost]` |
| Gross Margin | Revenue minus cost | Period | Finance | `[Gross Margin]` |
| Gross Margin % | Margin as a share of revenue | Period | Finance | `[Gross Margin %]` |
| Budget Variance | Actual revenue minus budget | BU / period | FP&A | `[Budget Variance]` |
| Top 10 Customer Revenue | Revenue from the 10 largest customers | Customer | Sales Finance | `[Top 10 Customer Revenue]` |
| Revenue Concentration % | Share of revenue from top 10 customers (risk indicator) | Period | Risk | `[Revenue Concentration % (Top 10)]` |
| Customer Tier | Platinum/Gold/Silver/Bronze by revenue rank | Customer | Sales | `[Customer Tier]` |

## Definitions of "done" for a certified KPI

- Documented business definition + grain + owner (this catalog).
- Backing DAX measure peer-reviewed and named per standards.
- Linked in the Purview business glossary to its physical column(s).
- Reconciled against source-of-truth (GL for revenue) within tolerance.
- Surfaced only from the certified semantic model.
