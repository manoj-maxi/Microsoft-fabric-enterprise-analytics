# Data Pipeline Flow

## Metadata-driven orchestration

Rather than hand-building a pipeline per source, a single parameterized pipeline iterates a control table. Adding a new source = one row in metadata, no new pipeline.

```mermaid
flowchart TD
    START([Trigger: Scheduled / Tumbling Window]) --> LK1[Lookup:<br/>read control.ingestion_metadata]
    LK1 --> FE{ForEach<br/>source entity}
    FE --> LK2[Lookup:<br/>last watermark for entity]
    LK2 --> CP[Copy Activity:<br/>pull rows WHERE key > watermark]
    CP --> OK{Rows<br/>copied?}
    OK -->|success| LAND[Land to Bronze Delta<br/>+ audit columns]
    OK -->|failure| DL[Route to Dead-Letter<br/>+ retry x3 exponential]
    LAND --> WM[Update watermark<br/>in control table]
    WM --> NB[Invoke Notebook:<br/>Bronze → Silver → Gold]
    NB --> VAL[Validate row counts<br/>& DQ summary]
    VAL --> LOG[Write run log<br/>control.pipeline_run_log]
    DL --> LOG
    LOG --> NEXT{More<br/>entities?}
    NEXT -->|yes| FE
    NEXT -->|no| END([Refresh notification +<br/>Purview lineage emit])
```

## Control table schema

```sql
CREATE TABLE control.ingestion_metadata (
    entity_id            INT,
    source_system        VARCHAR(50),     -- Snowflake | SQLServer | Oracle | REST | D365
    source_object        VARCHAR(200),    -- table / endpoint
    target_bronze_table  VARCHAR(200),
    load_type            VARCHAR(20),     -- FULL | INCREMENTAL
    watermark_column     VARCHAR(100),    -- e.g. modified_ts
    watermark_value      VARCHAR(50),     -- last successful high-water mark
    is_active            BIT,
    sla_minutes          INT
);
```

## Incremental load patterns

| Source | Pattern | Mechanism |
|--------|---------|-----------|
| SQL Server CDRs | CDC | `sys.fn_cdc_get_all_changes`, captured net changes |
| Snowflake billing | Watermark | `WHERE modified_ts > @last_watermark` |
| Oracle GL | Watermark | `WHERE last_update_date > :wm` |
| REST vendor API | Cursor pagination | `?since=<ts>&page=<n>` loop until empty |
| Dynamics 365 | Delta token | OData `$deltatoken` |

## Reliability features

- **Retry:** 3 attempts, exponential backoff (30s / 2m / 5m) on transient errors.
- **Dead-letter:** failed batches land in `bronze_deadletter/<entity>/<batch_id>/` for replay.
- **Idempotency:** each run stamped with `_batch_id`; re-runs `MERGE` rather than blind append.
- **Watermark safety:** watermark only advances after Bronze land + row-count validation succeed.
- **Alerting:** failures + SLA breaches emit to a Teams channel via pipeline webhook activity.

## Run log

```sql
CREATE TABLE control.pipeline_run_log (
    run_id          VARCHAR(50),
    entity_id       INT,
    started_ts      DATETIME2,
    ended_ts        DATETIME2,
    status          VARCHAR(20),   -- SUCCESS | FAILED | QUARANTINED
    rows_read       BIGINT,
    rows_written    BIGINT,
    rows_quarantined BIGINT,
    error_message   VARCHAR(4000)
);
```
